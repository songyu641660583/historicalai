<template>
  <div class="help-center">1</div>
</template>
<style lang="scss">
.help-center {
  
}
</style>