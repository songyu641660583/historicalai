<template>
   <div class="footer-YtwIpo">
     <div class="custom-module">试用体验内容均由人工智能模型生成，不代表平台立场 <span>免责声明</span><span>测试协议</span><span>隐私政策</span></div> 
          <!-- <div class=beian-QKzV2L>
            <div class=text-wdR8Ms>版权所有©北京西行漫记科技有限公司2025 </div>
            <div class=below-fXUkWQ>
              <div class=beianAndICP-GiJ8Fz><img class=badge-iAUu6L
                  src="../assets/702340561abc924294d76328b8a5c055.png"><a
                  href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010802032137" target=_blank
                  rel=noreferrer>京公网安备 11010802032137号</a> | <a href=https://beian.miit.gov.cn/#/Integrated/index
                  target=_blank rel=noreferrer>京ICP备20018813号-3</a></div>
              <div class=text-wdR8Ms>增值电信业务经营许可证：牌照京B2-20202418</div>
            </div>
          </div> -->
        </div>
</template>
<style>
.footer-YtwIpo {
  height: 80px;
  line-height: 80px;
  align-items: center;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  font-size: 14px;
  color: #999;
}
.custom-module {
  text-align: center;
}
.custom-module span {
  cursor: pointer;
  margin-left: 30px;
}

.beian-QKzV2L {
  padding-bottom: 10px
}

.beian-QKzV2L .text-wdR8Ms {
  color: #41464f;
  font-size: 12px;
  font-weight: 400;
  letter-spacing: .2px;
  line-height: 20px;
  text-align: center
}

.beian-QKzV2L .below-fXUkWQ {
  align-items: center;
  display: flex
}

.beian-QKzV2L .below-fXUkWQ .beianAndICP-GiJ8Fz {
  margin-right: 20px
}

.beian-QKzV2L .below-fXUkWQ .beianAndICP-GiJ8Fz .badge-iAUu6L {
  float: left;
  height: 12px;
  margin: 4px 4px 0 0;
  width: 12px
}

.beian-QKzV2L .below-fXUkWQ .beianAndICP-GiJ8Fz a {
  color: #41464f;
  font-size: 12px;
  font-weight: 400;
  letter-spacing: .2px;
  line-height: 20px
}
@media screen and (max-width:1200px) and (min-width:768px) {
 
  .footer-YtwIpo {
    box-sizing: border-box;
    min-width: 768px
  }
}

@media screen and (max-width:768px) {
 .footer-YtwIpo {
    box-sizing: border-box;
    min-width: unset
  }
}
</style>